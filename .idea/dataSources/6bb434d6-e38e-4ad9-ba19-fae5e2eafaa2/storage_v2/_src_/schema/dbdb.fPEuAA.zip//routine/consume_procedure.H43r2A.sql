create
    definer = root@`%` procedure consume_procedure(IN oldid varchar(20))
BEGIN

SELECT type, sum(price) from view_orderdetail
where oid = oldid
GROUP BY type;


END;

