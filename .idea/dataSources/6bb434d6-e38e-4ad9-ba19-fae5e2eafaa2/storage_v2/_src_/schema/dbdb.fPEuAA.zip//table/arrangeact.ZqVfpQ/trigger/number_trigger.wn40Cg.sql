create definer = root@`%` trigger number_trigger
    before update
    on arrangeact
    for each row
BEGIN
if (SELECT capacity FROM place
WHERE id=new.site
) < new.number
then
SIGNAL SQLSTATE '45000'

SET MESSAGE_TEXT = 'over capacity';

end if;
end;

