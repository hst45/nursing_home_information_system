create view viewactnum as
select `dbdb`.`carer`.`cid`        AS `cid`,
       `dbdb`.`carer`.`name`       AS `name`,
       `dbdb`.`activitynum`.`task` AS `task`,
       `dbdb`.`arrangeact`.`day`   AS `day`,
       `dbdb`.`arrangeact`.`time1` AS `time1`,
       `dbdb`.`arrangeact`.`time2` AS `time2`,
       `dbdb`.`activity`.`name`    AS `title`,
       `dbdb`.`arrangeact`.`id`    AS `id`
from (((`dbdb`.`activitynum` join `dbdb`.`arrangeact` on ((`dbdb`.`activitynum`.`aid` = `dbdb`.`arrangeact`.`id`))) join `dbdb`.`carer` on ((`dbdb`.`activitynum`.`cid` = `dbdb`.`carer`.`cid`)))
         join `dbdb`.`activity` on ((`dbdb`.`arrangeact`.`activity` = `dbdb`.`activity`.`id`)));

