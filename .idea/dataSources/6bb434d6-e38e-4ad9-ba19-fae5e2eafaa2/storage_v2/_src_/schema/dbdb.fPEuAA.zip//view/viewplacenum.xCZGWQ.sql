create view viewplacenum as
select `dbdb`.`arrangeact`.`day`  AS `day`,
       `dbdb`.`arrangeact`.`site` AS `site`,
       `dbdb`.`place`.`name`      AS `name`,
       `dbdb`.`place`.`type`      AS `type`
from (`dbdb`.`arrangeact`
         join `dbdb`.`place` on ((`dbdb`.`arrangeact`.`site` = `dbdb`.`place`.`id`)));

