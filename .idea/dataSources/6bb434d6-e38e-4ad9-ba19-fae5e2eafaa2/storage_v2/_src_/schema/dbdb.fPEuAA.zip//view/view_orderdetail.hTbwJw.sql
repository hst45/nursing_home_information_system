create view view_orderdetail as
select `dbdb`.`orderdetails`.`goodsid` AS `goodsid`,
       `dbdb`.`orderdetails`.`num`     AS `num`,
       `dbdb`.`orderdetails`.`price`   AS `price`,
       `dbdb`.`goods`.`name`           AS `name`,
       `dbdb`.`order`.`oid`            AS `oid`,
       `dbdb`.`orderdetails`.`orderid` AS `orderid`,
       `dbdb`.`goods`.`type`           AS `type`,
       `dbdb`.`order`.`time`           AS `time`
from ((`dbdb`.`goods` join `dbdb`.`orderdetails` on ((`dbdb`.`orderdetails`.`goodsid` = `dbdb`.`goods`.`id`)))
         join `dbdb`.`order` on ((`dbdb`.`order`.`id` = `dbdb`.`orderdetails`.`orderid`)))
where (`dbdb`.`goods`.`id` = `dbdb`.`orderdetails`.`goodsid`);

