create definer = root@`%` trigger time_site_trigger
    before insert
    on arrangeact
    for each row
BEGIN
if EXISTS(
SELECT *
FROM arrangeact
where( not(time1>New.time2 or time2<new.time1) and (site=new.site) and (day=new.day) )
)then
SIGNAL SQLSTATE '45000'

SET MESSAGE_TEXT = 'time.';

end if;
end;

