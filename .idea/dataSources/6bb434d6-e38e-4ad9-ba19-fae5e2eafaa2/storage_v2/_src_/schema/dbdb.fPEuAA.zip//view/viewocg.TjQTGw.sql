create view viewocg as
select `dbdb`.`guardian`.`idcard`   AS `idcard`,
       `dbdb`.`guardian`.`name`     AS `name`,
       `dbdb`.`guardian`.`gender`   AS `gender`,
       `dbdb`.`guardian`.`birthday` AS `birthday`,
       `dbdb`.`guardian`.`address`  AS `address`,
       `dbdb`.`guardian`.`tele`     AS `tele`,
       `dbdb`.`guardian`.`oid`      AS `oid`,
       `dbdb`.`old`.`name`          AS `oldname`,
       `dbdb`.`carer`.`cid`         AS `cid`
from ((`dbdb`.`carer` join `dbdb`.`old` on ((`dbdb`.`old`.`carer` = `dbdb`.`carer`.`cid`)))
         join `dbdb`.`guardian` on ((`dbdb`.`guardian`.`oid` = `dbdb`.`old`.`id`)));

