create
    definer = root@`%` procedure g()
begin
declare now date;
declare onemonth date;
declare threedays date;
declare threemonths date;
declare oneyear date;
set now= (select NOW()) ;
set onemonth=(select date_add(now, interval -1 month));
set threemonths=(select date_add(now, interval -3 month));
set threedays=(select date_add(now, interval -3 day));
set oneyear=(select date_add(now, interval -1 year));
SELECT type,count(CASE WHEN time <= threedays THEN 1 ELSE NULL END) as 次数
from viewgoodsnum
GROUP BY type
UNION ALL
SELECT type,count(CASE WHEN time <= onemonth THEN 1 ELSE NULL END) as 次数
from viewgoodsnum
GROUP BY type
UNION ALL
SELECT type,count(CASE WHEN time <= threemonths THEN 1 ELSE NULL END) as 次数
from viewgoodsnum
GROUP BY type
UNION ALL
SELECT type,count(CASE WHEN time <= oneyear THEN 1 ELSE NULL END) as 次数
#不然的话0项不会显示
from viewgoodsnum
GROUP BY type;
end;

