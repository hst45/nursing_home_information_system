create view view_oldschedule as
select `dbdb`.`schedule`.`oid`               AS `oid`,
       `dbdb`.`schedule`.`actid`             AS `actid`,
       hour(`dbdb`.`arrangeact`.`time1`)     AS `shour`,
       minute(`dbdb`.`arrangeact`.`time1`)   AS `smin`,
       hour(`dbdb`.`arrangeact`.`time2`)     AS `ehour`,
       minute(`dbdb`.`arrangeact`.`time2`)   AS `emin`,
       year(`dbdb`.`arrangeact`.`day`)       AS `year`,
       month(`dbdb`.`arrangeact`.`day`)      AS `month`,
       dayofmonth(`dbdb`.`arrangeact`.`day`) AS `day`,
       `dbdb`.`arrangeact`.`site`            AS `site`,
       `dbdb`.`arrangeact`.`activity`        AS `activity`,
       `dbdb`.`arrangeact`.`number`          AS `number`,
       `dbdb`.`activity`.`name`              AS `name`,
       `dbdb`.`activity`.`note`              AS `notes`,
       `dbdb`.`activity`.`type`              AS `type`,
       `dbdb`.`activity`.`capacity`          AS `capacity`
from ((`dbdb`.`schedule` join `dbdb`.`arrangeact` on ((`dbdb`.`schedule`.`actid` = `dbdb`.`arrangeact`.`id`)))
         join `dbdb`.`activity` on ((`dbdb`.`arrangeact`.`activity` = `dbdb`.`activity`.`id`)));

