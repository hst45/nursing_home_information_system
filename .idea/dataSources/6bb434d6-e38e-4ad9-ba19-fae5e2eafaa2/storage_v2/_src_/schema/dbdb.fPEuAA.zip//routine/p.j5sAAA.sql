create
    definer = root@`%` procedure p()
begin
declare now date;
declare onemonth date;
declare threedays date;
declare threemonths date;
declare oneyear date;
set now= (select NOW()) ;
set onemonth=(select date_add(now, interval -1 month));
set threemonths=(select date_add(now, interval -3 month));
set threedays=(select date_add(now, interval -3 day));
set oneyear=(select date_add(now, interval -1 year));
SELECT type,count(CASE WHEN day <= now THEN 1 ELSE NULL END) as 次数
from viewplacenum
GROUP BY type
UNION ALL
SELECT type,count(CASE WHEN day <= threedays THEN 1 ELSE NULL END) as 次数
from viewplacenum
GROUP BY type
UNION ALL
SELECT type,count(CASE WHEN day <= onemonth THEN 1 ELSE NULL END) as 次数
from viewplacenum
GROUP BY type
UNION ALL
SELECT type,count(CASE WHEN day <= threemonths THEN 1 ELSE NULL END) as 次数
from viewplacenum
GROUP BY type
UNION ALL
SELECT type,count(CASE WHEN day <= oneyear THEN 1 ELSE NULL END) as 次数
#不然的话0项不会显示
from viewplacenum
GROUP BY type;
end;

