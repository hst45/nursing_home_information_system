create view viewactivity as
select `dbdb`.`activity`.`name`    AS `title`,
       `dbdb`.`activity`.`content` AS `content`,
       `dbdb`.`activity`.`note`    AS `note`,
       `dbdb`.`arrangeact`.`id`    AS `id`,
       `dbdb`.`arrangeact`.`day`   AS `day`,
       `dbdb`.`arrangeact`.`time1` AS `time1`,
       `dbdb`.`arrangeact`.`time2` AS `time2`,
       `dbdb`.`place`.`location`   AS `location`,
       `dbdb`.`place`.`name`       AS `name`
from ((`dbdb`.`activity` join `dbdb`.`arrangeact` on ((`dbdb`.`arrangeact`.`activity` = `dbdb`.`activity`.`id`)))
         join `dbdb`.`place` on ((`dbdb`.`arrangeact`.`site` = `dbdb`.`place`.`id`)));

