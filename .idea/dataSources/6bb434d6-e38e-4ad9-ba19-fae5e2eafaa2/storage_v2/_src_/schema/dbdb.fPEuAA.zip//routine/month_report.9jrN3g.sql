create
    definer = root@`%` procedure month_report(IN oldid varchar(20), IN year varchar(20))
BEGIN
	#Routine body goes here...
	SELECT Month(time) month, sum(price) from view_orderdetail
	where (oid = oldid) and (YEAR(time)=year)
	GROUP BY month;

END;

