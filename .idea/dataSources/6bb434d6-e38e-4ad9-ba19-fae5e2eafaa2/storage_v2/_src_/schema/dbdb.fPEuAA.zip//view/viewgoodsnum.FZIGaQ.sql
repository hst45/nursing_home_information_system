create view viewgoodsnum as
select `dbdb`.`order`.`time`           AS `time`,
       `dbdb`.`orderdetails`.`orderid` AS `orderid`,
       `dbdb`.`order`.`id`             AS `id`,
       `dbdb`.`orderdetails`.`goodsid` AS `goodsid`,
       `dbdb`.`goods`.`name`           AS `name`,
       `dbdb`.`goods`.`type`           AS `type`
from ((`dbdb`.`order` join `dbdb`.`orderdetails` on ((`dbdb`.`order`.`id` = `dbdb`.`orderdetails`.`orderid`)))
         join `dbdb`.`goods` on ((`dbdb`.`orderdetails`.`goodsid` = `dbdb`.`goods`.`id`)));

