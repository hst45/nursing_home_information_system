create definer = root@`%` trigger price_triggger
    after insert
    on goods
    for each row
begin
if NEW.price <0
then
SIGNAL SQLSTATE '45000'

SET MESSAGE_TEXT = 'Original language id is required for Foreign language films.';

END IF;

END;

