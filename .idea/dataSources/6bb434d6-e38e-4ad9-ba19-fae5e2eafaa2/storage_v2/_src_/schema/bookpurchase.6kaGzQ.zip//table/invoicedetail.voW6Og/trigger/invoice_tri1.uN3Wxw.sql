create definer = root@`%` trigger invoice_tri1
    after insert
    on invoicedetail
    for each row
BEGIN
    DECLARE finished INT DEFAULT 0;
		DECLARE ind char(10);
		DECLARE ic decimal(10,2);
		DECLARE inp decimal(10,2);
		DEClARE intp decimal(10,2);
		DECLARE curInvoiceDetail CURSOR FOR
        SELECT invoiceId FROM invoicedetail
        GROUP BY invoiceId;
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
		OPEN curInvoiceDetail;
		FETCH curInvoiceDetail INTO ind;
		WHILE finished!=1 DO
		     SELECT sum(invoicedetail.price*invoicedetail.quantity) into inp
				 FROM invoicedetail
         WHERE invoicedetail.invoiceId=ind
				 GROUP BY invoicedetail.invoiceId;
				 SELECT sum(invoicedetail.price*invoicedetail.quantity*invoicedetail.taxRate) into intp
				 FROM invoicedetail
         WHERE invoicedetail.invoiceId=ind
				 GROUP BY invoicedetail.invoiceId;
				 UPDATE invoicemaster
				 SET invoiceTotal=inp,taxTotal=intp
				 WHERE invoicemaster.invoiceId=ind;
				 FETCH curInvoiceDetail INTO ind;
    END WHILE;
		CLOSE curInvoiceDetail;
END;

