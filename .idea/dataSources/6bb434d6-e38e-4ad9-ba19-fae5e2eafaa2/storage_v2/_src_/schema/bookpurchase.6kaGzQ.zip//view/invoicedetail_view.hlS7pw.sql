create view invoicedetail_view as
select `bookpurchase`.`invoicedetail`.`invoiceId`                                           AS `invoiceId`,
       `bookpurchase`.`invoicedetail`.`ISBN`                                                AS `ISBN`,
       `bookpurchase`.`invoicedetail`.`title`                                               AS `title`,
       `bookpurchase`.`invoicedetail`.`price`                                               AS `price`,
       `bookpurchase`.`invoicedetail`.`quantity`                                            AS `quantity`,
       (`bookpurchase`.`invoicedetail`.`price` * `bookpurchase`.`invoicedetail`.`quantity`) AS `sumPrice`,
       `bookpurchase`.`invoicedetail`.`taxRate`                                             AS `taxRate`,
       ((`bookpurchase`.`invoicedetail`.`price` * `bookpurchase`.`invoicedetail`.`quantity`) *
        `bookpurchase`.`invoicedetail`.`taxRate`)                                           AS `sumTax`
from (`bookpurchase`.`invoicedetail`
         join `bookpurchase`.`invoicemaster`)
where (`bookpurchase`.`invoicedetail`.`invoiceId` = `bookpurchase`.`invoicemaster`.`invoiceId`);

