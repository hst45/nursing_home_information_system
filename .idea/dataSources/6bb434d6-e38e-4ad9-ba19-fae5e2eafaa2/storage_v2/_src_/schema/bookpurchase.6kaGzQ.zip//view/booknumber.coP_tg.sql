create view booknumber as
select `bookpurchase`.`catalog`.`bookId`    AS `bookId`,
       `bookpurchase`.`catalog`.`catalogId` AS `catalogId`,
       `bookpurchase`.`catalog`.`ISBN`      AS `ISBN`,
       `bookpurchase`.`book`.`bookTitle`    AS `bookTitle`,
       `bookpurchase`.`book`.`author`       AS `author`,
       `bookpurchase`.`book`.`publishDate`  AS `publish_date`,
       `bookpurchase`.`book`.`version`      AS `version`,
       `bookpurchase`.`book`.`category`     AS `category`,
       `bookpurchase`.`book`.`stockNumber`  AS `stockNumber`,
       `bookpurchase`.`book`.`pressName`    AS `pressName`
from (`bookpurchase`.`catalog`
         join `bookpurchase`.`book`)
where (`bookpurchase`.`catalog`.`ISBN` = `bookpurchase`.`book`.`isbn`);

