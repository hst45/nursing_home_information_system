create view listmaster_view as
select `bookpurchase`.`listmaster`.`listId`    AS `listId`,
       `bookpurchase`.`company`.`companyTitle` AS `companyTitle`,
       `bookpurchase`.`listmaster`.`prodate`   AS `prodate`
from (`bookpurchase`.`listmaster`
         join `bookpurchase`.`company`)
where (`bookpurchase`.`listmaster`.`companyId` = `bookpurchase`.`company`.`companyId`);

