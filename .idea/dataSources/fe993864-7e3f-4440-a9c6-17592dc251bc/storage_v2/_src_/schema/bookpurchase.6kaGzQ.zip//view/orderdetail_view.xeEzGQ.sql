create view orderdetail_view as
select `bookpurchase`.`ordermaster`.`orderId`  AS `orderId`,
       `bookpurchase`.`listdetail`.`bookTitle` AS `bookTitle`,
       `bookpurchase`.`orderdetail`.`isbn`     AS `ISBN`,
       `bookpurchase`.`listdetail`.`price`     AS `price`,
       `bookpurchase`.`orderdetail`.`quantity` AS `quantity`,
       `bookpurchase`.`ordergroup`.`oUserName` AS `operator`,
       `bookpurchase`.`company`.`companyTitle` AS `supplier`,
       `bookpurchase`.`listmaster`.`listId`    AS `listId`
from (((((`bookpurchase`.`orderdetail` join `bookpurchase`.`ordermaster`) join `bookpurchase`.`listmaster`) join `bookpurchase`.`listdetail`) join `bookpurchase`.`company`)
         join `bookpurchase`.`ordergroup`)
where ((`bookpurchase`.`orderdetail`.`orderId` = `bookpurchase`.`ordermaster`.`orderId`) and
       (`bookpurchase`.`ordermaster`.`listId` = `bookpurchase`.`listmaster`.`listId`) and
       (`bookpurchase`.`listmaster`.`listId` = `bookpurchase`.`listdetail`.`listId`) and
       (`bookpurchase`.`listdetail`.`ISBN` = `bookpurchase`.`orderdetail`.`isbn`) and
       (`bookpurchase`.`listmaster`.`companyId` = `bookpurchase`.`company`.`companyId`) and
       (`bookpurchase`.`ordermaster`.`employeeId` = `bookpurchase`.`ordergroup`.`oUserId`));

