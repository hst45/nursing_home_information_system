create
    definer = root@`%` procedure new_list_detail(IN listId char(12), IN ISBN char(17), IN bookTitle varchar(60),
                                                 IN author varchar(50), IN publishDate date, IN version int,
                                                 IN category varchar(30), IN price decimal(10, 2),
                                                 IN introduction varchar(500), IN pressName varchar(30))
BEGIN
  #添加供书目录图书
	DECLARE i int;
	declare t_error integer default 0;
    declare continue handler for sqlexception set t_error=1;
    start transaction;
	insert into listdetail(listId,ISBN,bookTitle,author,publishDate,version,category,price,introduction,pressName)values(listId,ISBN,bookTitle,author,publishDate,version,category,price,introduction,pressName);
	if t_error=1 then
		rollback;
	else
		commit;
	end if;

END;

