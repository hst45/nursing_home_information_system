create
    definer = root@`%` procedure delete_list_detail(IN dId char(12), IN dISBN char(17))
BEGIN
	DECLARE i int;
	declare t_error integer default 0;
    declare continue handler for sqlexception set t_error=1;
    start transaction;
  delete from listdetail where listId=dId ANd ISBN = dISBN;
	#删除供书目录中的图书：获取供书目录编号和图书ISBN号，删除对应的listdetail表中记录
	if t_error=1 then
		rollback;
	else
		commit;
	end if;
END;

