create definer = root@`%` trigger tri2
    after update
    on orderdetail
    for each row
BEGIN
	  DECLARE done INT DEFAULT 0;
    DECLARE oid char(15);
		DECLARE op decimal(10,2);
    DECLARE curOrderDetail CURSOR FOR
        SELECT orderId FROM orderdetail
        GROUP BY orderId;
	  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
	  OPEN curOrderDetail;
		FETCH curOrderDetail INTO oid;
		WHILE done != 1 DO
		      SELECT sum(listdetail.price * quantity) into op
          FROM orderdetail,ordermaster,listmaster,listdetail
          WHERE orderdetail.orderId  = oid AND orderdetail.orderId=ordermaster.orderId AND ordermaster.listId=listmaster.listId AND listmaster.listId=listdetail.listId AND listdetail.ISBN=orderdetail.isbn
          GROUP BY orderdetail.orderId;
		      UPDATE ordermaster
          SET orderPrice  = op
          WHERE orderId = oid;
					FETCH curOrderDetail INTO oid;
    END WHILE;
		CLOSE curOrderDetail;
END;

