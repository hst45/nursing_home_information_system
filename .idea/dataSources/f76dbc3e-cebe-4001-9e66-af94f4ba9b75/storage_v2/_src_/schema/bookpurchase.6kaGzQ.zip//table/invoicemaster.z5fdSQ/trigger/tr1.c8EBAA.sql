create definer = root@`%` trigger tr1
    after update
    on invoicemaster
    for each row
BEGIN
    DECLARE finished INT DEFAULT 0;
		DECLARE isn char(17);
		DECLARE ic int;
		DECLARE bc int;
		DECLARE cn int;
		DECLARE ed char(10);
		DECLARE od char(15);
		DECLARE su int;
		DECLARE curCheck CURSOR FOR
        SELECT isbn FROM book
        GROUP BY isbn;
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
		OPEN curCheck;
		FETCH curCheck INTO isn;
		WHILE finished!=1 DO
				 SELECT sum(quantity) into ic FROM invoicedetail,invoicemaster WHERE invoicedetail.ISBN=isn AND invoicedetail.invoiceId=invoicemaster.invoiceId AND invoicemaster.flag=1
				 GROUP BY invoicedetail.ISBN;
				 SELECT book.stockNumber into bc FROM book WHERE book.isbn=isn;
				 SELECT invoicemaster.orderId,invoicemaster.employeeId into od,ed
				 FROM invoicemaster
				 WHERE invoicemaster.invoiceId=NEW.invoiceId;
				 SET cn=bc+ic-9;
				 if(cn>0)
				    then insert into checkdetail(checkdetail.ISBN,checkdetail.checkDate,checkdetail.quantity,checkdetail.orderId,checkdetail.employeeId) values(isn,DATE_FORMAT(NOW(), '%Y-%m-%d'),cn,od,ed);
				 end if;
				 FETCH curCheck INTO isn;
    END WHILE;
		CLOSE curCheck;
END;

