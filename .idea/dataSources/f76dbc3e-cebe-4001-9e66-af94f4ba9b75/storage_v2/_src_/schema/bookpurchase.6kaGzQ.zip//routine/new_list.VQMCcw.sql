create
    definer = root@`%` procedure new_list(IN listId char(12), IN companyId int)
BEGIN
  #创建供书目录，输入list_id，company_id需要存在于company表中，prodate自动获取
	DECLARE i int;
	declare t_error integer default 0;
    declare continue handler for sqlexception set t_error=1;
    start transaction;
	insert into listmaster(listId,companyId,prodate)values (listId,companyId,current_date());
	if t_error=1 then
		rollback;
	else
		commit;
	end if;

END;

