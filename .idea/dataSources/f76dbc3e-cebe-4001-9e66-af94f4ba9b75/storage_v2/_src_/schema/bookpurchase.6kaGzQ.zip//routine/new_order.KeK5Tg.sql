create
    definer = root@`%` procedure new_order(IN orderId char(15), IN orderDate date, IN employeeId int,
                                           IN listId char(12), IN isbn char(17), IN quantity int, IN num int)
BEGIN
	#employee_id为当前登录账号编号,list_id需要读取当前供书目录编号，num为当前供书目录下已选择订购的图书数量,quantity是每个图书的订购数量
  DECLARE i int;
	declare t_error integer default 0;
    declare continue handler for sqlexception set t_error=1;
    start transaction;
		insert into ordermaster(orderId,orderDate,employeeId,listId)values (orderId,CURRENT_DATE(),employeeId,listId);
		SET i=0;
	while i<num DO
		insert into orderdetail(orderId,isbn,quantity) values(orderId,isbn,quantity);
		SET i=i+1;
	end while;

    if t_error=1 then
		rollback;
	else
		commit;
	end if;
END;

