create definer = root@`%` trigger idtri1
    before insert
    on checkdetail
    for each row
BEGIN
    DECLARE n INT;

SELECT
    IFNULL(MAX(RIGHT(checkId, 2)), 0) INTO n
FROM checkdetail
WHERE
    MID(checkDate, 1, 10) = DATE_FORMAT(NOW(), '%Y-%m-%d');

    SET NEW.checkId = CONCAT(DATE_FORMAT(NOW(), '%Y%m%d'),RIGHT (101 + n, 2));

END;

